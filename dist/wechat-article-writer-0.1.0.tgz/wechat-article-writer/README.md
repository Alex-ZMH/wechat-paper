# 公众号推文写作助手

一个按 MatterAI Agent Kit v2 规范组织的微信公众号内容写作智能体包。它可以把一个主题、素材或粗稿整理成适合公众号发布的推文，并在发布前完成基础编辑检查。

## 可以做什么

- 根据主题生成选题角度、读者价值与文章大纲。
- 将用户提供的材料改写为完整推文：标题、导语、正文、小标题、结尾互动与配图建议。
- 对已有草稿进行结构、节奏、事实边界、标题和发布前检查。
- 根据品牌调性与目标读者生成多个标题和开头版本。

## 开始使用

给智能体提供尽可能多的上下文：主题、读者、目标、已有材料、希望的字数、语气、品牌禁忌和发布时间。示例：

```text
为“周末给自己留出两小时”写一篇 1200 字公众号推文。
读者是 25–35 岁的一线城市上班族，语气温和、具体、不说教。
文章目标是引导读者保存并留言。不要编造研究结论；已有素材如下：……
```

若用户只给出一个主题，智能体会先给出可执行的选题方向与大纲，并标出需要用户确认的假设。

## 目录

```text
wechat-article-writer/
  bundle.json
  agents/wechat-article-writer/AGENT.md
  skills/wechat-article-writing/SKILL.md
  harness/cases/
  harness/rubrics/
```

## 验证

本 bundle 遵循 MatterAI Agent Kit 的 Bundle v2 规范。若本机已有 Agent Kit，可从其根目录运行：

```bash
node bin/matterai-bundle.mjs validate "C:\\Users\\ironman\\Documents\\公众号\\wechat-article-writer"
node bin/matterai-bundle.mjs eval "C:\\Users\\ironman\\Documents\\公众号\\wechat-article-writer"
node bin/matterai-bundle.mjs pack "C:\\Users\\ironman\\Documents\\公众号\\wechat-article-writer"
```

该 bundle 不连接微信公众平台；请在人工审核后将最终文稿粘贴到公众号后台并完成排版、预览和发布。

## 对接实际公众号 API（可选）

若已在微信公众平台注册并取得 AppID 与 AppSecret，可使用 [API 对接说明](integrations/wechat-api/README.md) 在本机验证凭证。凭证只应存在于你的本机环境变量或可信部署平台，绝不能提交到仓库、打包文件或聊天记录。

已提供“凭证验证 → 上传素材 → 创建草稿”的本机脚本；草稿必须在公众号后台人工预览与审核。自动发布或群发需要你确认账号权限、平台配置和审核规则后再启用。
