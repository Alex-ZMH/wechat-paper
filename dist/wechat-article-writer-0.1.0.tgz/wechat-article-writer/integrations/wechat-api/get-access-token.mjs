/**
 * Minimal, local-only WeChat Official Account credential check.
 *
 * Usage (PowerShell):
 *   $env:WECHAT_APP_ID='...'
 *   $env:WECHAT_APP_SECRET='...'
 *   node get-access-token.mjs
 *
 * This intentionally never prints or writes the access token. It only reports
 * whether the configured credentials were accepted by the API.
 */

const appId = process.env.WECHAT_APP_ID?.trim()
const appSecret = process.env.WECHAT_APP_SECRET?.trim()

if (!appId || !appSecret) {
  console.error('Missing WECHAT_APP_ID or WECHAT_APP_SECRET. Set them as local environment variables; do not put secrets in source files.')
  process.exitCode = 1
} else {
  const requestUrl = new URL('https://api.weixin.qq.com/cgi-bin/token')
  requestUrl.searchParams.set('grant_type', 'client_credential')
  requestUrl.searchParams.set('appid', appId)
  requestUrl.searchParams.set('secret', appSecret)

  try {
    const response = await fetch(requestUrl, {
      headers: { accept: 'application/json' },
      signal: AbortSignal.timeout(15_000),
    })
    const payload = await response.json().catch(() => null)

    if (!response.ok || !payload?.access_token) {
      const errorCode = payload?.errcode ?? `HTTP ${response.status}`
      const errorMessage = payload?.errmsg ?? 'Unexpected response from the WeChat API'
      console.error(`Credential check failed: ${errorCode} ${errorMessage}`)
      process.exitCode = 1
    } else {
      console.log(`Credential check passed. The API returned an access token with a reported lifetime of ${payload.expires_in ?? 'unknown'} seconds.`)
    }
  } catch (error) {
    console.error(`Credential check could not reach the WeChat API: ${error instanceof Error ? error.message : String(error)}`)
    process.exitCode = 1
  }
}
